--- Creating Tables
---- customers_table

create table customers(customer_id	varchar(10)	primary key,
                       customer_name	varchar (50),
                       email	varchar (100),
                       gender	varchar (8),
                       city	varchar(20),
                       signup_date	date);

--- products_table

create table products(product_id	varchar(10)	primary key,
                      product_name	varchar (30),
                      category	varchar (25),
                      price	numeric (6,2),
                      stock_quantity	numeric (10));

--- orders_table

create table orders(order_id	varchar(10)	primary key,
                    customer_id	varchar (10),
                    product_id	varchar (12),	
                    order_date	date,
                    quantity	numeric (4),
                    total_price	numeric (8,2),	
                    status	varchar(20));

---payments_table

create table payments(payment_id varchar(12) primary key,
                      order_id	varchar (10),
                      payment_type	varchar (20),
                      payment_date	date,
                      amount	numeric (8,2));

--- deliveries_table

create table deliveries(delivery_id	varchar(12)	primary key,
                        order_id	varchar (12),
                        delivery_status	varchar (20),
                        delivery_date	date);
						
--- churn_data_table

create table churn_data(customer_id	varchar(12)	not null,
                        last_order_date	date,
                        is_churned	boolean);

--- imported data manually

------------------- General Data Cleaning Checks
--- 1. Duplicate Rows

select customer_id, count(*)
from churn_data
group by customer_id having count(*) > 1;

--- 2. Missing or Null Values

select * from deliveries 
         where delivery_status is null 
		 or delivery_date is null and delivery_status != 'Cancelled'
		 and delivery_status !='Returned';

select * from payments
         where payment_type is null or payment_date is null 
		 or order_amount is null;

--- 3. Outliers or Inconsistent Values

select min(price) as min_price,
       max(price) as max_price,
	   max(stock_quantity) as max_stock
from products;

--- 4. Order/Delivery Status Validation for data consistency
----- (i) Data Consistency check for orders marked as Completed

select o.order_id, o.status, d.delivery_status, p.payment_type
from orders o 
join deliveries d on o.order_id = d.order_id
join payments p on o.order_id = p.order_id
where o.status = 'Completed' and d.delivery_status in ('Cancelled', 'Returned');

----- (ii) Data Consistency check for orders marked as Returned


select o.order_id, o.status, d.delivery_status, p.payment_type
from orders o 
join deliveries d on o.order_id = d.order_id
join payments p on o.order_id = p.order_id
where o.status = 'Returned' and d.delivery_status in ('Cancelled', 'In Transit', 'Delivered');

----- Flagging as Inconsistent data which is not allowed to update or no decision yet

alter table deliveries add column delivery_flag varchar(20);

update deliveries
       set delivery_flag = 'Incosistent Data' where order_id 
	   in (select order_id from orders where status = 'Returned' 
	   and delivery_status = 'Shipped');

----- (iii) Data Consistency check for orders marked as Cancelled

select o.order_id, o.status, d.delivery_status, p.payment_type
from orders o 
join deliveries d on o.order_id = d.order_id
join payments p on o.order_id = p.order_id
where o.status = 'Cancelled' 
and d.delivery_status in ('Returned', 'Shipped', 'In Transit', 'Delivered');

----5. Solution to Query 04 Part 03(Found Data Inconsistency)

update deliveries 
       set delivery_status = 'Cancelled' where order_id 
	   in(select order_id from orders where status = 'Cancelled' and delivery_status 
	   in('Returned', 'Shipped', 'In Transit', 'Delivered'));

----6. Revenue Update and Consistency based on Order Status

update payments
            set amount = null 
			where order_id in 
			(select order_id from orders where status in ('Cancelled', 'Returned')
			and payment_type = 'Cash on Delivery');

update orders 
        set total_amount = null where order_id in
		(select order_id from payments where payment_type = 'Cash on Delivery' and 
		status in ('Returned', 'Cancelled'));

----7. Revenue correction for cancelled and returned prepaid orders with 10% deduction

alter table orders add column total_revenue numeric(10,2);

alter table payments add column order_amount numeric(10,2);

update orders
       set total_revenue = (10 * total_amount)/100 where order_id 
	   in (select order_id from payments where payment_type in ('Debit Card', 'Credit Card', 'PayPal')
	   and status in ('Returned', 'Cancelled') );
	   
update orders 
       set total_revenue = total_amount * 1
	   where total_revenue is null;
	   

update payments
       set order_amount = (10 * amount)/100 where order_id 
	   in (select order_id from orders where status in ('Returned', 'Cancelled')
	   and payment_type in ('Debit Card', 'Credit Card', 'PayPal') );

update payments 
       set order_amount = amount * 1
	   where order_amount is null;

alter table orders drop column total_amount;

update payments p
        set payment_date = null where order_id in
		(select order_id from orders where status in ('Returned', 'Cancelled')
		and payment_type = 'Cash on Delivery');

