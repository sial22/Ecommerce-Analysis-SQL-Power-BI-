
------------------------Insights To Be pulled out
----8.Customer Life Value based on Order value and Frequency

select customer_id,
      sum(total_revenue) as lifetime_value,
	  round(avg(total_revenue),2) as avg_order_value
from orders 
    where status = 'Completed'
	group by customer_id
	order by avg_order_value desc;

----9. Top 75 Spending Customers Complete Data

with tc as 
      (select customer_id,
      sum(total_revenue) as life_time_value
from orders 
    where status = 'Completed'
	group by customer_id
	order by life_time_value desc
	limit 75),
cd as 
    (select tc.customer_id, c.customer_name, c.email, c.gender, c.city, 
	        tc.life_time_value, c.signup_date
	from customers c
	inner join tc on c.customer_id = tc.customer_id)
select * from cd
	order by life_time_value desc
	limit 75;

---10. Repeat Purchase Rate

with orr as 
         (select customer_id,
		 count(distinct(order_id)) as total_orders
		 from orders where status = 'Completed'
		 group by customer_id
		 order by total_orders desc),
rc as 
        (select 
		count (case when total_orders > 1 then 1 end) as repeat_customers
		from orr),
cc as
       (select
	   count(distinct(customer_id)) as total_customers
	   from customers)
select 
      round((repeat_customers *100 /total_customers),2) as rpr from rc, cc;	

---11. Top 05 cities contributing to churn vs retention

with churned as 
         (select ct.city,
		 count(ch.customer_id) as churned 
		 from customers ct join churn_data ch on ct.customer_id = ch.customer_id
		 where ch.is_churned = 'true' group by ct.city
		 order by churned desc limit 5),
active as 
 (select ct.city,
		 count(ch.customer_id) as active 
		 from customers ct join churn_data ch on ct.customer_id = ch.customer_id
		 where ch.is_churned = 'false' group by ct.city
		 order by active desc limit 5)
		 
select city, churned, null as active, 'Churned' as category from churned 
union all select city, null as churned, active, 'active' as category from active;

---12. Monthly, Quarterly and Yearly Revenue Trends
------------Monthly
select 
      date_trunc('month', order_date ):: date as month,
	  sum(total_revenue) as monthly_revenue
from orders
      where status= 'Completed'
	  group by month
	  order by month;
	  
------------Quarterly

select 
      date_trunc('quarter', order_date ):: date as quarter_start,
	  sum(total_revenue) as monthly_revenue
from orders
       where status= 'Completed'
	   group by quarter_start
	  order by quarter_start;
	  
------------Yearly

select 
      extract(year from order_date) as year,
	  sum(total_revenue) as yearly_revenue
from orders
     where status= 'Completed'
	 group by year
	 order by year;

---13. Product_Category wise Performance like units sold cancel and return rate

select p.category,
       count(o.order_id) as total_orders,
       count(case when o.status = 'Cancelled' then 1 end) as cancelled_orders,
	   count(case when o.status = 'Returned' then 1 end) as returned_orders,
	   round(count(case when o.status = 'Cancelled' then 1 end)  * 100 :: numeric /
	   count(o.order_id),2) as cancel_rate,
	   round(count(case when o.status = 'Returned' then 1 end)  * 100 :: numeric /
	   count(o.order_id),2) as return_rate  
from products p join orders o on p.product_id = o.product_id
	 group by p.category 
	 order by p.category;

---14. Top 05 Best Selling Products based on Revenue

select p.product_id, p.product_name, p.category,
      sum(o.total_revenue) as revenue 
	  from products p join orders o on p.product_id = o.product_id
	  group by p.product_id
	  order by revenue desc
	  limit 5;

---15.Bottom 05 Products based on Revenue

select p.product_id, p.product_name, p.category,
      sum(o.total_revenue) as revenue 
	  from products p join orders o on p.product_id = o.product_id
	  group by p.product_id
	  order by revenue asc
	  limit 5;
	  
---16.  Stockout Risk, products with high sales but low stock

select p.product_id, p.product_name, p.stock_quantity,
      sum(o.quantity) as q_sold 
	  from products p join orders o on p.product_id = o.product_id
	  group by p.product_id, p.product_name, p.stock_quantity
	  having sum(o.quantity) > 350 and p.stock_quantity <50;

--- 17. Revenue Breakdown by payment method

select payment_type, 
       sum(order_amount) as payment_method_revenue
from payments 
       group by payment_type
	   order by payment_type;
		 


